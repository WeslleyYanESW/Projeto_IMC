function calculaIMC(){
    peso = parseFloat(document.formulario.peso.value);
    altura = parseFloat(document.formulario.altura.value);
    resultado = peso/(altura*altura);
    resultado = resultado.toFixed(2);

    if (resultado != null && resultado != "NaN") {
    	document.getElementById("resultado").innerHTML = "Resultado: " + resultado;
    }
    
    
}